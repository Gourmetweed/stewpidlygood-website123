import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-charcoal px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-mustard font-display">404</h1>
        <h2 className="mt-4 text-xl font-display text-white">PAGE NOT FOUND</h2>
        <div className="mt-6">
          <Link to="/" className="inline-flex items-center justify-center bg-mustard px-6 py-3 text-sm font-display text-charcoal">
            GO HOME
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  return (
    <div className="flex min-h-screen items-center justify-center bg-charcoal px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-display text-mustard">SOMETHING BROKE</h1>
        <p className="mt-2 text-sm text-white/70">Try again or head home.</p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button onClick={() => { router.invalidate(); reset(); }} className="bg-mustard px-4 py-2 text-sm font-display text-charcoal">TRY AGAIN</button>
          <a href="/" className="border border-mustard px-4 py-2 text-sm font-display text-mustard">GO HOME</a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "STEWPIDLY GOOD — Mad Bowls. Happy Souls." },
      { name: "description", content: "Slow-simmered global comfort stews. Cult-grade $STEWPID rewards, Web3 wallet, and merch burn — Oslo, NO." },
      { property: "og:title", content: "STEWPIDLY GOOD" },
      { property: "og:description", content: "Mad Bowls. Happy Souls." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Oswald:wght@500;600;700&family=Inter:wght@400;500;600&display=swap" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head><HeadContent /></head>
      <body>{children}<Scripts /></body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  return (
    <QueryClientProvider client={queryClient}>
      <Outlet />
    </QueryClientProvider>
  );
}
